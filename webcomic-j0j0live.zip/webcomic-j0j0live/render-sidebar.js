/* ============================================
   render-sidebar.js — Trending, categorias, recientes, comentarios,
   social y footer + aplicacion de i18n a todo el documento
   ============================================ */
import { escapeHtml } from './utils.js';
import { t, langState } from './i18n.js';
import {
  TRENDING,
  CATEGORIES,
  RECENT_ADDED,
  COMMENTS,
  SOCIAL_LINKS,
  SOCIAL_ICON_PATHS,
  FOOTER_COLUMNS,
  ICONS,
} from './data.js';
import { renderFilterTabs, renderGalleryPage } from './render-gallery.js';
import { browseState } from './state.js';

export function renderTrending(items) {
  const list = document.getElementById('trendingList');
  if (!list) return;
  if (items.length === 0) {
    list.innerHTML = `<li class="trending-empty">${escapeHtml(t('emptyResults'))}</li>`;
    return;
  }
  list.innerHTML = items.map(({ id, rank, rating, viewsCount }) => `
    <li class="trending-item" role="listitem">
      <span class="trending-rank">${escapeHtml(rank)}</span>
      <div class="trending-thumb">
        <span class="rating-badge">${escapeHtml(rating)}</span>
      </div>
      <div class="trending-info">
        <span class="trending-name">${escapeHtml(t(`trendingName_${id}`))}</span>
        <span class="trending-views">${escapeHtml(viewsCount)} ${escapeHtml(t('viewsSuffix'))}</span>
      </div>
    </li>
  `).join('');
}

export function renderCategories(items) {
  const list = document.getElementById('categoryList');
  if (!list) return;
  list.innerHTML = items.map(({ id, count }) => `
    <li role="listitem">
      <a href="#showcase" class="category-chip">
        <span>${escapeHtml(t(`categoryName_${id}`))}</span>
        <span class="category-count">${count}</span>
      </a>
    </li>
  `).join('');
}

export function renderRecentAdded(items) {
  const list = document.getElementById('recentList');
  if (!list) return;
  list.innerHTML = items.map(({ number, daysAgo }) => `
    <li class="recent-item" role="listitem">
      <div class="recent-thumb">
        ${daysAgo === 0 ? `<span class="recent-new-badge">${escapeHtml(t('recentAddedNewBadge'))}</span>` : ''}
      </div>
      <div class="recent-info">
        <strong>${escapeHtml(t('chapterPrefix'))} ${number}</strong>
        <span>${escapeHtml(t(`recentAddedAgo${daysAgo}`))}</span>
      </div>
    </li>
  `).join('');
}

export function renderComments(items) {
  const list = document.getElementById('commentsList');
  if (!list) return;
  list.innerHTML = items.map(({ id, authorInitials, authorName, chapterNumber, timeAgo }) => `
    <li class="comment-item" role="listitem">
      <span class="comment-avatar" aria-hidden="true">${escapeHtml(authorInitials)}</span>
      <div class="comment-body">
        <div class="comment-meta">
          <span class="comment-author">${escapeHtml(authorName)}</span>
          <span class="comment-chapter">${escapeHtml(t('chapterPrefix'))} ${chapterNumber}</span>
          <span class="comment-time">${escapeHtml(t(`commentTimeAgo${timeAgo}`))}</span>
        </div>
        <p class="comment-text">${escapeHtml(t(`comment_${id}`))}</p>
      </div>
    </li>
  `).join('');
}

export function renderSocialLinks(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = SOCIAL_LINKS.map(({ key, label }) => `
    <a href="#" aria-label="${escapeHtml(label)}" role="listitem">${SOCIAL_ICON_PATHS[key]}</a>
  `).join('');
}

export function renderFooterColumns(columns) {
  const container = document.getElementById('footerColumns');
  if (!container) return;
  container.innerHTML = columns.map(({ titleKey, icon, links }) => `
    <div class="footer-col">
      <div class="footer-col-header">
        ${ICONS[icon]}
        <h3>${escapeHtml(t(titleKey))}</h3>
      </div>
      <span class="footer-col-underline"></span>
      <ul class="footer-links">
        ${links.map(({ label, labelKey, href }) => `<li><a href="${escapeHtml(href)}">${escapeHtml(labelKey ? t(labelKey) : label)}</a></li>`).join('')}
      </ul>
    </div>
  `).join('');
}

export function applyTranslations() {
  document.documentElement.setAttribute('lang', langState.current);

  document.querySelectorAll('[data-i18n]').forEach((el) => {
    el.textContent = t(el.dataset.i18n);
  });

  document.querySelectorAll('[data-i18n-html]').forEach((el) => {
    el.innerHTML = t(el.dataset.i18nHtml);
  });

  document.querySelectorAll('[data-i18n-attr]').forEach((el) => {
    const attrMap = JSON.parse(el.dataset.i18nAttr);
    Object.entries(attrMap).forEach(([attr, key]) => el.setAttribute(attr, t(key)));
  });

  renderFilterTabs();
  renderGalleryPage(browseState.page, false);
  renderTrending(TRENDING);
  renderCategories(CATEGORIES);
  renderRecentAdded(RECENT_ADDED);
  renderComments(COMMENTS);
  renderFooterColumns(FOOTER_COLUMNS);

  const langToggle = document.getElementById('langToggle');
  if (langToggle) langToggle.textContent = langState.current === 'es' ? 'EN' : 'ES';
}
