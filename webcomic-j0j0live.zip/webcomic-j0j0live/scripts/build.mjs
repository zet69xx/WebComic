// ============================================
// scripts/build.mjs — Build de produccion
//
// Los 8 modulos ES (main.js + sus imports) quedan sin bundlear en el
// codigo fuente a proposito: es mas facil de leer y debuggear durante
// desarrollo. Este script los bundlea y minifica en un solo archivo
// para servir en produccion, junto con el CSS minificado.
//
// Uso: npm install && npm run build
// ============================================
import { build, transform } from 'esbuild';
import { readFile, writeFile, mkdir, cp, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const dist = path.join(root, 'dist');

async function sizeOf(filePath) {
  const { size } = await stat(filePath);
  return size;
}

async function main() {
  await mkdir(dist, { recursive: true });

  // ---- JS: bundle + minify de main.js y todo lo que importa ----
  const jsResult = await build({
    entryPoints: [path.join(root, 'main.js')],
    bundle: true,
    minify: true,
    format: 'esm',
    target: 'es2019',
    outfile: path.join(dist, 'main.min.js'),
    metafile: true,
  });

  // ---- CSS: minify ----
  const cssSource = await readFile(path.join(root, 'style.css'), 'utf-8');
  const cssResult = await transform(cssSource, { loader: 'css', minify: true });
  await writeFile(path.join(dist, 'style.min.css'), cssResult.code);

  // ---- HTML: mismo documento, apuntando a los archivos ya bundleados ----
  let html = await readFile(path.join(root, 'index.html'), 'utf-8');
  html = html
    .replace('href="style.css"', 'href="style.min.css"')
    .replace('src="main.js"', 'src="main.min.js"');
  await writeFile(path.join(dist, 'index.html'), html);

  // ---- Assets estaticos ----
  await cp(path.join(root, 'assets'), path.join(dist, 'assets'), { recursive: true });

  // ---- Reporte de tamaños ----
  const jsSrcFiles = ['main.js', 'modal.js', 'events.js', 'i18n.js', 'data.js', 'state.js', 'utils.js', 'render-gallery.js', 'render-sidebar.js'];
  let jsSrcTotal = 0;
  for (const f of jsSrcFiles) jsSrcTotal += await sizeOf(path.join(root, f));
  const jsDistSize = await sizeOf(path.join(dist, 'main.min.js'));
  const cssSrcSize = await sizeOf(path.join(root, 'style.css'));
  const cssDistSize = await sizeOf(path.join(dist, 'style.min.css'));

  console.log('--- Build OK ---');
  console.log(`JS:  ${jsSrcFiles.length} archivos, ${jsSrcTotal} bytes  ->  1 archivo, ${jsDistSize} bytes  (${(100 - (jsDistSize / jsSrcTotal) * 100).toFixed(1)}% menos, ${jsSrcFiles.length - 1} requests menos)`);
  console.log(`CSS: ${cssSrcSize} bytes  ->  ${cssDistSize} bytes  (${(100 - (cssDistSize / cssSrcSize) * 100).toFixed(1)}% menos)`);
  console.log(`Salida en: ${dist}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
