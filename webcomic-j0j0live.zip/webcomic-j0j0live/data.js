/* ============================================
   data.js — Contenido estatico del sitio (capitulos, sidebar, footer, iconos)
   ============================================ */
import { seededRandom } from './utils.js';

export const GALLERY_PAGE_SIZE = 20;
export const PREVIEW_LINE_COUNT = 8;

// Set de portadas ilustradas originales (arte de tinta abstracto, sin
// personajes ni obras existentes), se ciclan entre los 48 capitulos igual
// que antes se ciclaban los gradientes de PANEL_VARIANTS.
export const COVER_ART = [
  { file: 'assets/covers/cover-splatter.svg', descKey: 'coverDescSplatter' },
  { file: 'assets/covers/cover-speedlines.svg', descKey: 'coverDescSpeedlines' },
  { file: 'assets/covers/cover-fracture.svg', descKey: 'coverDescFracture' },
  { file: 'assets/covers/cover-storm.svg', descKey: 'coverDescStorm' },
  { file: 'assets/covers/cover-brushwork.svg', descKey: 'coverDescBrushwork' },
  { file: 'assets/covers/cover-moon.svg', descKey: 'coverDescMoon' },
];

// 48 capitulos generados de forma deterministica
export const CHAPTERS = Array.from({ length: 48 }, (_, i) => {
  const number = 48 - i;
  const noise = seededRandom(number);
  const views = Math.round(200 + i * 14 + noise * 130);
  const rating = Math.min(5, Math.round((3.8 + noise * 0.9 + i * 0.002) * 10) / 10);
  const cover = COVER_ART[number % COVER_ART.length];
  return { number, views, rating, cover };
});

export const TRENDING = [
  { id: 'ronin', rank: '01', rating: '4.9', viewsCount: '32.4k' },
  { id: 'katana', rank: '02', rating: '4.8', viewsCount: '27.1k' },
  { id: 'shibuya', rank: '03', rating: '4.7', viewsCount: '21.6k' },
  { id: 'laststroke', rank: '04', rating: '4.6', viewsCount: '18.9k' },
  { id: 'neon', rank: '05', rating: '4.5', viewsCount: '15.2k' },
];

export const CATEGORIES = [
  { id: 'accion', count: 18 },
  { id: 'drama', count: 12 },
  { id: 'sobrenatural', count: 9 },
  { id: 'comedia', count: 7 },
  { id: 'romance', count: 6 },
  { id: 'aventura', count: 5 },
];

export const RECENT_ADDED = [
  { number: 48, daysAgo: 0 },
  { number: 47, daysAgo: 1 },
  { number: 46, daysAgo: 3 },
  { number: 45, daysAgo: 4 },
];

export const COMMENTS = [
  { id: 'c1', authorInitials: 'RT', authorName: 'Renji T.', chapterNumber: 48, timeAgo: 0 },
  { id: 'c2', authorInitials: 'MK', authorName: 'Mika K.', chapterNumber: 47, timeAgo: 1 },
  { id: 'c3', authorInitials: 'DL', authorName: 'Diego L.', chapterNumber: 46, timeAgo: 2 },
  { id: 'c4', authorInitials: 'SA', authorName: 'Sofia A.', chapterNumber: 45, timeAgo: 3 },
  { id: 'c5', authorInitials: 'JT', authorName: 'Jin T.', chapterNumber: 48, timeAgo: 0 },
  { id: 'c6', authorInitials: 'YM', authorName: 'Yuki M.', chapterNumber: 46, timeAgo: 1 },
];

export const FILTER_TABS = [
  { id: 'visits', labelKey: 'filterVisits' },
  { id: 'points', labelKey: 'filterPoints' },
  { id: 'comments', labelKey: 'filterComments' },
];

export const SOCIAL_LINKS = [
  { key: 'instagram', label: 'Instagram' },
  { key: 'x', label: 'X' },
  { key: 'discord', label: 'Discord' },
];

export const SOCIAL_ICON_PATHS = {
  instagram:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="16" height="16" rx="4"/><circle cx="12" cy="12" r="3.5"/><circle cx="16.6" cy="7.4" r="0.9" fill="currentColor" stroke="none"/></svg>',
  x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 5l14 14M19 5L5 19"/></svg>',
  discord:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="8" width="16" height="10" rx="5"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/><circle cx="9" cy="13" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="13" r="1.2" fill="currentColor" stroke="none"/></svg>',
};

export const ICONS = {
  sitemap:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="9" y="14" width="6" height="6" rx="1"/><path d="M7 10v2a2 2 0 0 0 2 2"/><path d="M17 10v2a2 2 0 0 1-2 2"/></svg>',
  compass:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><polygon points="14.5,9.5 12,14.5 9.5,9.5 12,12"/></svg>',
  link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 15l6-6"/><path d="M8 12l-2 2a3 3 0 0 0 4 4l2-2"/><path d="M16 12l2-2a3 3 0 0 0-4-4l-2 2"/></svg>',
};

export const FOOTER_COLUMNS = [
  {
    titleKey: 'colSite',
    icon: 'sitemap',
    links: [
      { labelKey: 'linkFaq', href: '#' },
      { labelKey: 'linkCollab', href: '#' },
      { labelKey: 'linkRules', href: '#' },
      { labelKey: 'linkTerms', href: '#' },
      { labelKey: 'linkPrivacy', href: '#' },
      { labelKey: 'linkCookies', href: '#' },
      { labelKey: 'linkContact', href: 'mailto:info@webcomic.com' },
    ],
  },
  {
    titleKey: 'colExplore',
    icon: 'compass',
    links: [
      { labelKey: 'linkChapters', href: '#showcase' },
      { labelKey: 'linkCharacters', href: '#' },
      { labelKey: 'linkConceptArt', href: '#' },
      { labelKey: 'linkExtras', href: '#' },
      { labelKey: 'linkLibrary', href: '#' },
    ],
  },
  {
    titleKey: 'colFriends',
    icon: 'link',
    links: [
      { label: 'Colectivo Manga LATAM', href: '#' },
      { label: 'Estudio Ronin', href: '#' },
    ],
  },
];

export const EYE_ICON =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/></svg>';
