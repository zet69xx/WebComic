/* ============================================
   utils.js — Helpers genericos sin estado y sin dependencias
   ============================================ */

// Escape basico para prevenir XSS (aunque los datos son internos, se usa por buenas practicas)
export function escapeHtml(text) {
  if (!text) return text;
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Debounce para busqueda
export function debounce(fn, delay = 300) {
  let timer;
  return function (...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}

// Generador pseudo-aleatorio deterministico (misma semilla = mismo resultado)
export function seededRandom(seed) {
  const x = Math.sin(seed * 9301 + 49297) * 233280;
  return x - Math.floor(x);
}

// Genera los tokens de paginacion (numeros + '...') para un total de paginas dado
export function getPaginationTokens(current, total, delta = 1) {
  const range = [];
  for (let i = Math.max(2, current - delta); i <= Math.min(total - 1, current + delta); i++) range.push(i);
  const tokens = [1];
  if (range[0] > 2) tokens.push('...');
  tokens.push(...range);
  if (range[range.length - 1] < total - 1) tokens.push('...');
  if (total > 1) tokens.push(total);
  return tokens;
}
