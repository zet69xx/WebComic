/* ============================================
   main.js — Punto de entrada de la app
   ============================================ */
import { applyTranslations, renderSocialLinks } from './render-sidebar.js';
import { initModal } from './modal.js';
import {
  initLangToggle,
  initFilterTabs,
  initGalleryPagination,
  initTrendingSearch,
  initThemeToggle,
  initMobileMenu,
  initBackToTop,
} from './events.js';

document.addEventListener('DOMContentLoaded', () => {
  applyTranslations();

  initLangToggle();
  initFilterTabs();
  initGalleryPagination();
  initTrendingSearch();
  initModal();
  initThemeToggle();
  initMobileMenu();
  initBackToTop();

  renderSocialLinks('heroSocial');
  renderSocialLinks('footerSocial');
});
