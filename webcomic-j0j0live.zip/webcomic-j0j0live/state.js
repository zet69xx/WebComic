/* ============================================
   state.js — Estado de navegacion de la galeria (filtro, pagina, resultados)
   ============================================ */
import { CHAPTERS, FILTER_TABS, COMMENTS } from './data.js';

export const browseState = {
  filter: FILTER_TABS[0].id,
  page: 1,
  chapters: [...CHAPTERS],
};

// Mapa precalculado de cantidad de comentarios por capitulo (O(1) al ordenar por "Comentados")
export const commentCountMap = new Map();
COMMENTS.forEach((c) => {
  commentCountMap.set(c.chapterNumber, (commentCountMap.get(c.chapterNumber) || 0) + 1);
});
