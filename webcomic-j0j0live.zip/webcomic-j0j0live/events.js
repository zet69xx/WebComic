/* ============================================
   events.js — Listeners: idioma, filtros, paginacion, busqueda, modal,
   tema, menu movil, volver arriba
   ============================================ */
import { debounce } from './utils.js';
import { t, langState, setLang } from './i18n.js';
import { CHAPTERS, TRENDING, GALLERY_PAGE_SIZE } from './data.js';
import { browseState, commentCountMap } from './state.js';
import { renderFilterTabs, renderGalleryPage } from './render-gallery.js';
import { renderTrending, applyTranslations } from './render-sidebar.js';

// ---- Idioma ----
export function initLangToggle() {
  const langToggle = document.getElementById('langToggle');
  if (!langToggle) return;
  langToggle.addEventListener('click', () => {
    setLang(langState.current === 'es' ? 'en' : 'es');
    applyTranslations();
  });
}

// ---- Filtros con ordenamiento optimizado ----
export function initFilterTabs() {
  const container = document.getElementById('filterTabs');
  if (!container) return;
  container.addEventListener('click', (event) => {
    const btn = event.target.closest('button[data-filter]');
    if (!btn || btn.dataset.filter === browseState.filter) return;
    browseState.filter = btn.dataset.filter;
    renderFilterTabs();

    const sorted = [...CHAPTERS];
    if (browseState.filter === 'visits') {
      sorted.sort((a, b) => b.views - a.views);
    } else if (browseState.filter === 'points') {
      sorted.sort((a, b) => b.rating - a.rating);
    } else if (browseState.filter === 'comments') {
      // Usar el mapa precalculado para O(1) en cada comparacion
      sorted.sort((a, b) => {
        const countA = commentCountMap.get(a.number) || 0;
        const countB = commentCountMap.get(b.number) || 0;
        return countB - countA;
      });
    }
    browseState.chapters = sorted;
    renderGalleryPage(1);
  });
}

// ---- Paginacion ----
export function initGalleryPagination() {
  const nav = document.getElementById('galleryPagination');
  if (!nav) return;
  nav.addEventListener('click', (event) => {
    const btn = event.target.closest('button[data-page]');
    if (!btn || btn.disabled) return;
    const totalPages = Math.max(1, Math.ceil(browseState.chapters.length / GALLERY_PAGE_SIZE));
    const { page } = btn.dataset;
    if (page === 'prev') renderGalleryPage(browseState.page - 1);
    else if (page === 'next') renderGalleryPage(browseState.page + 1);
    else if (page === 'last') renderGalleryPage(totalPages);
    else renderGalleryPage(Number(page));
  });
}

// ---- Busqueda con debounce ----
export function initTrendingSearch() {
  const input = document.getElementById('trendingSearchInput');
  if (!input) return;

  const handleSearch = debounce((event) => {
    const query = event.target.value.trim().toLowerCase();
    const filtered = TRENDING.filter(({ id }) => t(`trendingName_${id}`).toLowerCase().includes(query));
    renderTrending(filtered);
  }, 300);

  input.addEventListener('input', handleSearch);
}

// ---- Modal (ver modal.js) ----

// ---- Tema oscuro ----
export function initThemeToggle() {
  const toggle = document.getElementById('themeToggle');
  const root = document.documentElement;

  let saved = null;
  try {
    saved = localStorage.getItem('theme');
  } catch (err) {
    console.warn('No se pudo leer el tema guardado:', err);
  }

  const prefers = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const initial = saved || (prefers ? 'dark' : 'light');
  root.setAttribute('data-theme', initial);
  toggle.setAttribute('aria-pressed', String(initial === 'dark'));

  toggle.addEventListener('click', () => {
    const isDark = root.getAttribute('data-theme') === 'dark';
    const next = isDark ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    toggle.setAttribute('aria-pressed', String(next === 'dark'));
    try {
      localStorage.setItem('theme', next);
    } catch (err) {
      console.warn('No se pudo guardar el tema:', err);
    }
  });
}

// ---- Menu movil ----
export function initMobileMenu() {
  const toggle = document.getElementById('navToggle');
  const links = document.getElementById('navLinks');
  if (!toggle || !links) return;

  const closeMenu = () => {
    links.classList.remove('is-open');
    toggle.setAttribute('aria-expanded', 'false');
  };

  toggle.addEventListener('click', () => {
    const isOpen = links.classList.toggle('is-open');
    toggle.setAttribute('aria-expanded', String(isOpen));
  });

  links.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', closeMenu);
  });
}

// ---- Volver arriba ----
export function initBackToTop() {
  const button = document.getElementById('backToTop');
  if (!button) return;
  const sync = () => button.classList.toggle('is-visible', window.scrollY > 400);
  window.addEventListener('scroll', sync, { passive: true });
  button.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  sync();
}
