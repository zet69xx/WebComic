/* ============================================
   modal.js — Modal de detalle de capitulo con focus trap
   ============================================ */
import { t } from './i18n.js';

export function initModal() {
  const modal = document.getElementById('chapterModal');
  const overlay = document.getElementById('modalOverlay');
  const closeBtn = document.getElementById('modalClose');
  const grid = document.getElementById('galleryGrid');
  let lastFocusedElement = null;
  let focusableElements = [];

  function updateFocusableElements() {
    const selectors = 'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';
    const elements = modal.querySelectorAll(selectors);
    focusableElements = Array.from(elements).filter((el) => !el.disabled);
  }

  function trapFocus(e) {
    if (e.key !== 'Tab') return;
    if (focusableElements.length === 0) {
      e.preventDefault();
      return;
    }
    const first = focusableElements[0];
    const last = focusableElements[focusableElements.length - 1];
    if (e.shiftKey) {
      if (document.activeElement === first) {
        last.focus();
        e.preventDefault();
      }
    } else if (document.activeElement === last) {
      first.focus();
      e.preventDefault();
    }
  }

  function openModal(chapterNumber, views, rating, preview) {
    lastFocusedElement = document.activeElement;
    document.getElementById('modalChapterNumber').textContent = chapterNumber;
    document.getElementById('modalPreview').textContent = preview;
    document.getElementById('modalViews').textContent = `👁️ ${views} ${t('viewsSuffix')}`;
    document.getElementById('modalRating').textContent = `⭐ ${rating}`;
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    updateFocusableElements();
    setTimeout(() => {
      closeBtn.focus();
    }, 20);
    modal.addEventListener('keydown', trapFocus);
  }

  function closeModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    modal.removeEventListener('keydown', trapFocus);
    if (lastFocusedElement) {
      lastFocusedElement.focus();
      lastFocusedElement = null;
    }
  }

  grid.addEventListener('click', (e) => {
    const item = e.target.closest('.gallery-item');
    if (!item) return;
    openModal(item.dataset.chapter, item.dataset.views, item.dataset.rating, item.dataset.preview);
  });

  grid.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ' || e.key === 'Spacebar') {
      const item = e.target.closest('.gallery-item');
      if (!item) return;
      e.preventDefault();
      openModal(item.dataset.chapter, item.dataset.views, item.dataset.rating, item.dataset.preview);
    }
  });

  overlay.addEventListener('click', closeModal);
  closeBtn.addEventListener('click', closeModal);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('is-open')) closeModal();
  });
}
