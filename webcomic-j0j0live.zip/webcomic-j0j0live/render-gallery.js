/* ============================================
   render-gallery.js — Grilla de capitulos, filtros y paginacion
   ============================================ */
import { escapeHtml, getPaginationTokens } from './utils.js';
import { t } from './i18n.js';
import { EYE_ICON, PREVIEW_LINE_COUNT, GALLERY_PAGE_SIZE, FILTER_TABS } from './data.js';
import { browseState } from './state.js';

export function renderFilterTabs() {
  const container = document.getElementById('filterTabs');
  if (!container) return;
  container.innerHTML = FILTER_TABS.map(({ id, labelKey }) => {
    const isActive = id === browseState.filter;
    return `<button type="button" class="filter-tab${isActive ? ' active' : ''}" role="tab" aria-selected="${isActive}" data-filter="${id}">${escapeHtml(t(labelKey))}</button>`;
  }).join('');
}

// Mismas 4 variantes de gradiente que usan los paneles del hero, para que
// la galeria se sienta parte del mismo sistema visual en vez de fotos sueltas.
const PANEL_VARIANTS = [
  { angle: '160deg', c1: '#1c1c1c', c2: '#050505' },
  { angle: '200deg', c1: '#2a2a2a', c2: '#0a0a0a' },
  { angle: '120deg', c1: '#151515', c2: '#000000' },
  { angle: '180deg', c1: '#232323', c2: '#070707' },
];

export function renderGallery(items) {
  const grid = document.getElementById('galleryGrid');
  if (!grid) return;

  const fragment = document.createDocumentFragment();

  items.forEach(({ number, views, rating, cover }, index) => {
    const ratingLabel = rating.toFixed(1);
    const chapterLabel = `${escapeHtml(t('chapterPrefix'))} ${number}`;
    const preview = escapeHtml(t(`previewLine${number % PREVIEW_LINE_COUNT}`));
    const ariaLabel = `${chapterLabel} — ${views} ${escapeHtml(t('viewsSuffix'))}, ${ratingLabel}/5`;
    const variant = PANEL_VARIANTS[number % PANEL_VARIANTS.length];
    // Primeras 5 tarjetas (primera fila) cargan eager; el resto, lazy,
    // ya que quedan debajo del pliegue.
    const isAboveFold = index < 5;
    const coverAlt = cover ? escapeHtml(`${t(cover.descKey)} — ${chapterLabel}`) : '';

    const card = document.createElement('div');
    card.className = 'gallery-item';
    card.style.setProperty('--panel-angle', variant.angle);
    card.style.setProperty('--panel-c1', variant.c1);
    card.style.setProperty('--panel-c2', variant.c2);
    card.setAttribute('tabindex', '0');
    card.setAttribute('role', 'listitem');
    card.setAttribute('aria-label', ariaLabel);
    card.dataset.chapter = number;
    card.dataset.views = views;
    card.dataset.rating = ratingLabel;
    card.dataset.preview = preview;

    card.innerHTML = `
      ${cover ? `<img class="gallery-item-cover" src="${escapeHtml(cover.file)}" alt="${coverAlt}" width="300" height="400" loading="${isAboveFold ? 'eager' : 'lazy'}" decoding="async" />` : ''}
      <span class="gallery-item-number" aria-hidden="true">${number}</span>
      <span class="gallery-views-badge">${EYE_ICON}${views}</span>
      <div class="gallery-item-overlay">
        <strong>${chapterLabel}</strong>
        <p>${preview}</p>
        <div class="gallery-item-overlay-meta">
          <span>${EYE_ICON}${views} ${escapeHtml(t('viewsSuffix'))}</span>
          <span class="gallery-item-overlay-rating">★ ${ratingLabel}</span>
        </div>
      </div>
      <div class="gallery-item-footer">
        <span class="tag">${chapterLabel}</span>
        <span class="gallery-rating"><span class="star" aria-hidden="true">★</span>${ratingLabel}</span>
      </div>
    `;
    fragment.appendChild(card);
  });

  grid.innerHTML = '';
  grid.appendChild(fragment);
}

export function renderPagination(current, total) {
  const nav = document.getElementById('galleryPagination');
  if (!nav) return;
  const pageButtons = getPaginationTokens(current, total).map((token) => {
    if (token === '...') return `<span class="pagination-ellipsis" aria-hidden="true">…</span>`;
    const isActive = token === current;
    return `<button type="button" class="pagination-btn${isActive ? ' active' : ''}" data-page="${token}"${isActive ? ' aria-current="page"' : ''}>${token}</button>`;
  }).join('');
  nav.innerHTML = `
    <button type="button" class="pagination-btn pagination-arrow" data-page="prev" aria-label="${escapeHtml(t('paginationPrev'))}"${current === 1 ? ' disabled' : ''}>‹</button>
    ${pageButtons}
    <button type="button" class="pagination-btn pagination-arrow" data-page="next" aria-label="${escapeHtml(t('paginationNext'))}"${current === total ? ' disabled' : ''}>›</button>
    <button type="button" class="pagination-btn pagination-last" data-page="last"${current === total ? ' disabled' : ''}>${escapeHtml(t('paginationLast'))}</button>
  `;
}

export function renderGalleryPage(page, scroll = true) {
  const totalPages = Math.max(1, Math.ceil(browseState.chapters.length / GALLERY_PAGE_SIZE));
  browseState.page = Math.min(Math.max(1, page), totalPages);
  const start = (browseState.page - 1) * GALLERY_PAGE_SIZE;
  renderGallery(browseState.chapters.slice(start, start + GALLERY_PAGE_SIZE));
  renderPagination(browseState.page, totalPages);
  if (scroll) {
    const grid = document.getElementById('galleryGrid');
    if (grid) grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}
